/**
 * Tipos fundamentales para el Ecosistema Educativo MDX
 * Motor de Presentaciones Interactivas (Paso 1)
 */

export type Disciplina = 'matematica' | 'fisica';

export interface ClaseMetadata {
  id: string;
  titulo: string;
  subtitulo: string;
  disciplina: Disciplina;
  ejeTematico: string; // Ej: "Álgebra y Funciones", "Mecánica"
  codigoPAES: string; // Ej: "PAES M1", "PAES Ciencias"
  duracionMinutos?: number;
  autor?: string;
  slidesCount?: number;
}

export interface Diapositiva {
  id: string;
  titulo?: string;
  categoria?: string;
  rawContent: string;
  notasDocente?: string;
}

export interface ClaseCompleta extends ClaseMetadata {
  rawMDX: string;
  slides: Diapositiva[];
}

export type ModoPantalla = 'presentacion' | 'docente' | 'editor';

export type TemaColor = 'claro-aula' | 'oscuro-proyector';

export interface PreguntaOpcion {
  id: 'A' | 'B' | 'C' | 'D' | 'E';
  texto: string;
  esCorrecta: boolean;
  justificacion?: string;
  distractorExplicacion?: string;
}

export interface PreguntaPAESData {
  id?: string;
  habilidad: 'Resolver Problemas' | 'Modelar' | 'Representar' | 'Argumentar';
  eje: string;
  enunciado: string;
  formulaLatex?: string;
  opciones: PreguntaOpcion[];
  claveOficial?: string;
}
