import React, { useState } from 'react';
import { BookOpen, AlertTriangle, Lightbulb, ChevronRight, CheckCircle2 } from 'lucide-react';
import { FormattedMathText } from '../../lib/katex-renderer';

interface BoxProps {
  titulo?: string;
  children: React.ReactNode;
  className?: string;
}

export const Definicion: React.FC<BoxProps> = ({ titulo = 'Definición Formal', children, className = '' }) => (
  <div className={`my-4 rounded-xl border border-blue-500/30 bg-blue-500/5 p-5 text-left shadow-sm ${className}`}>
    <div className="flex items-center gap-2 mb-2 text-blue-400 font-semibold tracking-wide text-sm uppercase">
      <BookOpen className="w-4 h-4" />
      <span>{titulo}</span>
    </div>
    <div className="text-slate-200 text-lg leading-relaxed font-normal">
      {typeof children === 'string' ? <FormattedMathText text={children} /> : children}
    </div>
  </div>
);

export const Propiedad: React.FC<BoxProps> = ({ titulo = 'Propiedad Fundamental', children, className = '' }) => (
  <div className={`my-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-5 text-left shadow-sm ${className}`}>
    <div className="flex items-center gap-2 mb-2 text-emerald-400 font-semibold tracking-wide text-sm uppercase">
      <Lightbulb className="w-4 h-4" />
      <span>{titulo}</span>
    </div>
    <div className="text-slate-200 text-lg leading-relaxed">
      {typeof children === 'string' ? <FormattedMathText text={children} /> : children}
    </div>
  </div>
);

export const ErrorFrecuente: React.FC<BoxProps> = ({ titulo = 'Error Típico PAES (¡Cuidado!)', children, className = '' }) => (
  <div className={`my-4 rounded-xl border border-amber-500/40 bg-amber-500/10 p-5 text-left shadow-sm ${className}`}>
    <div className="flex items-center gap-2 mb-2 text-amber-400 font-semibold tracking-wide text-sm uppercase">
      <AlertTriangle className="w-4 h-4" />
      <span>{titulo}</span>
    </div>
    <div className="text-amber-100/90 text-lg leading-relaxed">
      {typeof children === 'string' ? <FormattedMathText text={children} /> : children}
    </div>
  </div>
);

interface PasoReveladoProps {
  pasos: Array<{
    titulo: string;
    detalle: string;
  }>;
}

export const PasoRevelado: React.FC<PasoReveladoProps> = ({ pasos }) => {
  const [pasoActivo, setPasoActivo] = useState(0);

  return (
    <div className="my-5 w-full text-left space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-slate-700/60">
        <span className="text-xs font-mono tracking-wider text-slate-400 uppercase">
          Deducción paso a paso ({Math.min(pasoActivo + 1, pasos.length)} / {pasos.length})
        </span>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setPasoActivo((p) => Math.max(0, p - 1))}
            disabled={pasoActivo === 0}
            className="px-3 py-1.5 rounded-lg text-sm bg-slate-800 text-slate-300 disabled:opacity-40 hover:bg-slate-700 transition"
          >
            Anterior
          </button>
          <button
            type="button"
            onClick={() => setPasoActivo((p) => Math.min(pasos.length - 1, p + 1))}
            disabled={pasoActivo >= pasos.length - 1}
            className="px-4 py-1.5 rounded-lg text-sm font-semibold bg-blue-600 text-white disabled:opacity-40 hover:bg-blue-500 transition shadow"
          >
            Revelar Siguiente
          </button>
        </div>
      </div>

      <div className="space-y-3 pt-1">
        {pasos.map((item, idx) => {
          const visible = idx <= pasoActivo;
          return (
            <div
              key={idx}
              className={`p-4 rounded-xl border transition-all duration-300 ${
                visible
                  ? idx === pasoActivo
                    ? 'border-blue-500/60 bg-blue-950/20 text-slate-100 shadow-md'
                    : 'border-slate-800 bg-slate-900/40 text-slate-300'
                  : 'opacity-25 border-dashed border-slate-800 bg-transparent text-slate-500 cursor-pointer'
              }`}
              onClick={() => !visible && setPasoActivo(idx)}
            >
              <div className="flex items-center gap-2 font-medium text-sm mb-1">
                {visible ? (
                  <CheckCircle2 className={`w-4 h-4 ${idx === pasoActivo ? 'text-blue-400' : 'text-slate-500'}`} />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                )}
                <span>{item.titulo}</span>
              </div>
              {visible ? (
                <div className="pl-6 text-base leading-relaxed">
                  <FormattedMathText text={item.detalle} />
                </div>
              ) : (
                <div className="pl-6 text-xs font-mono text-slate-500 italic">
                  [Tocar para revelar este paso]
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
