import React, { useState } from 'react';
import { CheckCircle2, XCircle, HelpCircle, RotateCcw } from 'lucide-react';
import { PreguntaPAESData } from '../../types';
import { FormattedMathText } from '../../lib/katex-renderer';

export const PreguntaPAES: React.FC<PreguntaPAESData> = ({
  habilidad,
  eje,
  enunciado,
  opciones,
}) => {
  const [opcionSeleccionada, setOpcionSeleccionada] = useState<string | null>(null);
  const [revelado, setRevelado] = useState(false);

  const handleSelect = (id: string) => {
    setOpcionSeleccionada(id);
    setRevelado(true);
  };

  const handleReset = () => {
    setOpcionSeleccionada(null);
    setRevelado(false);
  };

  const getHabilidadColor = () => {
    switch (habilidad) {
      case 'Modelar':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'Representar':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'Argumentar':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
    }
  };

  const opcionElegidaData = opciones.find((o) => o.id === opcionSeleccionada);

  return (
    <div className="w-full my-4 p-6 rounded-2xl border border-slate-800 bg-slate-900/60 shadow-lg text-left">
      {/* Header con Etiquetas PAES DEMRE */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 text-xs font-semibold rounded-md uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700">
            {eje}
          </span>
          <span className={`px-2.5 py-1 text-xs font-semibold rounded-md border uppercase tracking-wider ${getHabilidadColor()}`}>
            Habilidad: {habilidad}
          </span>
        </div>

        {revelado && (
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reiniciar Pregunta</span>
          </button>
        )}
      </div>

      {/* Enunciado */}
      <div className="text-slate-100 text-xl font-normal leading-relaxed mb-6">
        <FormattedMathText text={enunciado} />
      </div>

      {/* Opciones con Target Táctil Grande para Tablet */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {opciones.map((opcion) => {
          const isSelected = opcionSeleccionada === opcion.id;
          let estadoClasses = 'border-slate-700/70 bg-slate-800/50 hover:bg-slate-800 text-slate-200';

          if (revelado) {
            if (opcion.esCorrecta) {
              estadoClasses = 'border-emerald-500 bg-emerald-950/30 text-emerald-200 ring-1 ring-emerald-500/50';
            } else if (isSelected && !opcion.esCorrecta) {
              estadoClasses = 'border-rose-500 bg-rose-950/30 text-rose-200 ring-1 ring-rose-500/50';
            } else {
              estadoClasses = 'border-slate-800/50 bg-slate-900/30 opacity-60 text-slate-400';
            }
          }

          return (
            <button
              key={opcion.id}
              type="button"
              onClick={() => handleSelect(opcion.id)}
              className={`flex items-start gap-3 p-4 rounded-xl border text-left transition-all duration-200 min-h-[60px] cursor-pointer ${estadoClasses}`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 mt-0.5 ${
                  revelado && opcion.esCorrecta
                    ? 'bg-emerald-500 text-slate-950'
                    : isSelected && !opcion.esCorrecta
                    ? 'bg-rose-500 text-white'
                    : 'bg-slate-700 text-slate-200'
                }`}
              >
                {opcion.id}
              </div>
              <div className="flex-1 text-base pt-0.5">
                <FormattedMathText text={opcion.texto} />
              </div>
              {revelado && opcion.esCorrecta && (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-1" />
              )}
              {revelado && isSelected && !opcion.esCorrecta && (
                <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-1" />
              )}
            </button>
          );
        })}
      </div>

      {/* Justificación pedagógica y análisis del distractor */}
      {revelado && opcionElegidaData && (
        <div className="mt-5 p-4 rounded-xl border border-slate-700 bg-slate-950/70 animate-in fade-in duration-300">
          <div className="flex items-center gap-2 mb-2 font-semibold text-sm">
            {opcionElegidaData.esCorrecta ? (
              <span className="text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> ¡Correcto! Clave oficial {opcionElegidaData.id}
              </span>
            ) : (
              <span className="text-rose-400 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4" /> Distractor seleccionado ({opcionElegidaData.id})
              </span>
            )}
          </div>

          <div className="text-slate-300 text-sm leading-relaxed">
            {opcionElegidaData.justificacion && (
              <div className="mb-2">
                <span className="text-slate-400 font-medium">Justificación: </span>
                <FormattedMathText text={opcionElegidaData.justificacion} />
              </div>
            )}
            {opcionElegidaData.distractorExplicacion && (
              <div className="text-amber-300/90 text-xs bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20">
                <span className="font-semibold">¿Por qué es un distractor común? </span>
                <FormattedMathText text={opcionElegidaData.distractorExplicacion} />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
