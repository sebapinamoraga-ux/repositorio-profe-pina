import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Menu,
  Layers,
  Sparkles,
} from 'lucide-react';

interface TouchControlsProps {
  slideActual: number;
  totalSlides: number;
  tituloClase: string;
  codigoPAES: string;
  onAnterior: () => void;
  onSiguiente: () => void;
  onIrASlide: (index: number) => void;
  onAbrirMenu: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  slideActual,
  totalSlides,
  tituloClase,
  codigoPAES,
  onAnterior,
  onSiguiente,
  onIrASlide,
  onAbrirMenu,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [mostrarSelectorSlide, setMostrarSelectorSlide] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  const progreso = ((slideActual + 1) / totalSlides) * 100;

  return (
    <>
      {/* Barra de Progreso Discreta Superior / Inferior */}
      <div className="fixed bottom-0 left-0 right-0 h-1.5 bg-slate-900 z-50">
        <div
          className="h-full bg-blue-500 transition-all duration-300 ease-out"
          style={{ width: `${progreso}%` }}
        />
      </div>

      {/* Dock Flotante Táctil de Control (Ergonomía Tablet: botones de 50px) */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-700/80 shadow-2xl">
        {/* Botón Menú de Clases */}
        <button
          type="button"
          onClick={onAbrirMenu}
          className="w-12 h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition border border-slate-700"
          title="Menú de Clases y Temas"
          aria-label="Abrir menú de clases"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Separador */}
        <div className="h-6 w-px bg-slate-700 mx-1" />

        {/* Botón Diapositiva Anterior */}
        <button
          type="button"
          onClick={onAnterior}
          disabled={slideActual === 0}
          className="w-13 h-13 rounded-xl bg-blue-900/30 hover:bg-blue-900/50 text-white disabled:opacity-30 flex items-center justify-center active:scale-90 transition border border-blue-600/40"
          title="Diapositiva Anterior"
          aria-label="Diapositiva Anterior"
        >
          <ChevronLeft className="w-7 h-7" />
        </button>

        {/* Indicador y Selector Rápido de Diapositiva */}
        <button
          type="button"
          onClick={() => setMostrarSelectorSlide(!mostrarSelectorSlide)}
          className="px-4 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 flex items-center gap-2 border border-slate-700 active:scale-95 transition"
        >
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="font-mono font-bold text-sm tracking-wider">
            {slideActual + 1} / {totalSlides}
          </span>
        </button>

        {/* Botón Diapositiva Siguiente */}
        <button
          type="button"
          onClick={onSiguiente}
          disabled={slideActual >= totalSlides - 1}
          className="w-13 h-13 rounded-xl bg-blue-600 hover:bg-blue-500 text-white disabled:opacity-30 flex items-center justify-center active:scale-90 transition shadow-lg shadow-blue-600/30 border border-blue-400/40"
          title="Diapositiva Siguiente"
          aria-label="Diapositiva Siguiente"
        >
          <ChevronRight className="w-7 h-7" />
        </button>

        {/* Separador */}
        <div className="h-6 w-px bg-slate-700 mx-1" />

        {/* Pantalla Completa para Proyección */}
        <button
          type="button"
          onClick={toggleFullscreen}
          className="w-12 h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 flex items-center justify-center active:scale-95 transition border border-slate-700"
          title={isFullscreen ? 'Salir de Pantalla Completa' : 'Modo Proyección Completa'}
          aria-label="Alternar pantalla completa"
        >
          {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
        </button>
      </div>

      {/* Popover / Menú flotante de Selección Rápida de Slide */}
      {mostrarSelectorSlide && (
        <div className="fixed bottom-22 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-slate-700 p-4 rounded-2xl shadow-2xl backdrop-blur-lg flex gap-2 max-w-[90vw] overflow-x-auto animate-in fade-in zoom-in-95">
          {Array.from({ length: totalSlides }).map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                onIrASlide(idx);
                setMostrarSelectorSlide(false);
              }}
              className={`w-12 h-12 rounded-xl font-bold font-mono text-sm flex items-center justify-center transition ${
                slideActual === idx
                  ? 'bg-blue-600 text-white shadow-lg ring-2 ring-blue-400'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>
      )}
    </>
  );
};
