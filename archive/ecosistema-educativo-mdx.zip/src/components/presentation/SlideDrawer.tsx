import React from 'react';
import { X, BookOpen, Atom, ChevronRight, CheckCircle2 } from 'lucide-react';
import { ClaseCompleta } from '../../types';

interface SlideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  clases: ClaseCompleta[];
  claseActualId: string;
  slideActualIndex: number;
  onSeleccionarClase: (claseId: string) => void;
  onSeleccionarSlide: (slideIndex: number) => void;
}

export const SlideDrawer: React.FC<SlideDrawerProps> = ({
  isOpen,
  onClose,
  clases,
  claseActualId,
  slideActualIndex,
  onSeleccionarClase,
  onSeleccionarSlide,
}) => {
  if (!isOpen) return null;

  const claseActiva = clases.find((c) => c.id === claseActualId) || clases[0];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Fondo oscurecido para cerrar */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Panel lateral */}
      <div className="relative w-full max-w-md bg-slate-900 border-r border-slate-800 shadow-2xl flex flex-col h-full z-10 text-left">
        {/* Cabecera del Drawer */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Índice de Clases</h2>
            <p className="text-xs text-slate-400">Preparación PAES M1 & Ciencias</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selector de Asignatura / Clase */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-950/40">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Seleccionar Unidad Temática
          </span>
          <div className="space-y-2">
            {clases.map((clase) => {
              const esActiva = clase.id === claseActualId;
              const esMate = clase.disciplina === 'matematica';

              return (
                <button
                  key={clase.id}
                  type="button"
                  onClick={() => onSeleccionarClase(clase.id)}
                  className={`w-full p-3 rounded-xl border text-left flex items-center gap-3 transition ${
                    esActiva
                      ? 'bg-blue-950/40 border-blue-500/60 text-white shadow-md'
                      : 'bg-slate-800/50 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                      esMate ? 'bg-blue-500/20 text-blue-400' : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {esMate ? <BookOpen className="w-5 h-5" /> : <Atom className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-mono font-medium text-slate-400 flex items-center gap-2">
                      <span>{clase.codigoPAES}</span>
                      <span>•</span>
                      <span>{clase.ejeTematico}</span>
                    </div>
                    <div className="text-sm font-semibold truncate text-slate-100">{clase.titulo}</div>
                  </div>
                  {esActiva && <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Diapositivas de la Clase Activa */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Diapositivas de esta clase ({claseActiva.slides.length})
          </span>

          {claseActiva.slides.map((slide, idx) => {
            const esSlideActual = idx === slideActualIndex;
            return (
              <button
                key={slide.id}
                type="button"
                onClick={() => {
                  onSeleccionarSlide(idx);
                  onClose();
                }}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-3 transition ${
                  esSlideActual
                    ? 'bg-blue-600 border-blue-400 text-white shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-md font-mono text-xs font-bold flex items-center justify-center shrink-0 ${
                    esSlideActual ? 'bg-white text-blue-900' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {idx + 1}
                </span>
                <div className="flex-1">
                  <div className={`text-xs uppercase tracking-wider font-semibold mb-0.5 ${
                    esSlideActual ? 'text-blue-200' : 'text-slate-400'
                  }`}>
                    {slide.categoria || `Slide ${idx + 1}`}
                  </div>
                  <div className="text-sm font-medium leading-snug">
                    {slide.titulo || `Diapositiva ${idx + 1}`}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 mt-1 ${esSlideActual ? 'text-white' : 'text-slate-600'}`} />
              </button>
            );
          })}
        </div>

        {/* Footer del Drawer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 text-xs text-slate-400 flex justify-between items-center">
          <span>Fuente Única: Markdown + KaTeX</span>
          <span className="font-mono">Paso 1: Motor 16:9</span>
        </div>
      </div>
    </div>
  );
};
