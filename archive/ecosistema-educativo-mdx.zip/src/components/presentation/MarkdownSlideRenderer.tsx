import React from 'react';
import { FormattedMathText, MathFormula } from '../../lib/katex-renderer';
import { Definicion, Propiedad, ErrorFrecuente, PasoRevelado } from '../layout/PedagogicalBoxes';
import { PreguntaPAES } from '../evaluation/PreguntaPAES';
import { ExploradorRecta } from '../math/ExploradorRecta';
import { RectaNumerica } from '../math/RectaNumerica';
import { SimuladorMRU } from '../physics/SimuladorMRU';

interface SlideRendererProps {
  rawContent: string;
}

export const MarkdownSlideRenderer: React.FC<SlideRendererProps> = ({ rawContent }) => {
  // Parser de bloques principales
  const renderContent = () => {
    const lines = rawContent.trim().split('\n');
    const elements: React.ReactNode[] = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i].trim();

      if (!line) {
        i++;
        continue;
      }

      // 1. Detección de Componentes Especiales Interactivos
      if (line.startsWith('<ExploradorRecta')) {
        elements.push(<ExploradorRecta key={`recta-${i}`} />);
        i++;
        continue;
      }

      if (line.startsWith('<RectaNumerica')) {
        elements.push(<RectaNumerica key={`ineq-${i}`} />);
        i++;
        continue;
      }

      if (line.startsWith('<SimuladorMRU')) {
        elements.push(<SimuladorMRU key={`mru-${i}`} />);
        i++;
        continue;
      }

      // 2. Detección de <PasoRevelado
      if (line.startsWith('<PasoRevelado')) {
        let blockStr = '';
        while (i < lines.length && !lines[i].includes('/>')) {
          blockStr += lines[i] + '\n';
          i++;
        }
        if (i < lines.length) {
          blockStr += lines[i];
          i++;
        }

        // Intenta parsear los pasos del atributo pasos={[...]}
        try {
          const pasosMatch = blockStr.match(/pasos=\{(\[[\s\S]*?\])\}/);
          if (pasosMatch) {
            // Reemplazo simple para evaluar de forma segura el objeto de pasos
            const jsonStr = pasosMatch[1]
              .replace(/titulo:/g, '"titulo":')
              .replace(/detalle:/g, '"detalle":')
              .replace(/,\s*\]/g, ']');
            const pasos = JSON.parse(jsonStr);
            elements.push(<PasoRevelado key={`pasos-${i}`} pasos={pasos} />);
            continue;
          }
        } catch (e) {
          console.warn('Fallback parsing paso revelado', e);
        }
      }

      // 3. Detección de <PreguntaPAES
      if (line.startsWith('<PreguntaPAES')) {
        let blockStr = '';
        while (i < lines.length && !lines[i].includes('/>')) {
          blockStr += lines[i] + '\n';
          i++;
        }
        if (i < lines.length) {
          blockStr += lines[i];
          i++;
        }

        try {
          const habMatch = blockStr.match(/habilidad="([^"]+)"/);
          const ejeMatch = blockStr.match(/eje="([^"]+)"/);
          const enunMatch = blockStr.match(/enunciado="([^"]+)"/);
          const opcionesMatch = blockStr.match(/opciones=\{(\[[\s\S]*?\])\}/);

          if (habMatch && ejeMatch && enunMatch && opcionesMatch) {
            const rawOpciones = opcionesMatch[1]
              .replace(/id:/g, '"id":')
              .replace(/texto:/g, '"texto":')
              .replace(/esCorrecta:/g, '"esCorrecta":')
              .replace(/justificacion:/g, '"justificacion":')
              .replace(/distractorExplicacion:/g, '"distractorExplicacion":')
              .replace(/,\s*\]/g, ']');

            const opciones = JSON.parse(rawOpciones);

            elements.push(
              <PreguntaPAES
                key={`paes-${i}`}
                habilidad={habMatch[1] as any}
                eje={ejeMatch[1]}
                enunciado={enunMatch[1]}
                opciones={opciones}
              />
            );
            continue;
          }
        } catch (e) {
          console.warn('Fallback parsing pregunta PAES', e);
        }
      }

      // 4. Detección de <Definicion, <Propiedad, <ErrorFrecuente
      if (line.startsWith('<Definicion') || line.startsWith('<Propiedad') || line.startsWith('<ErrorFrecuente')) {
        const isDef = line.startsWith('<Definicion');
        const isProp = line.startsWith('<Propiedad');
        const tagClose = isDef ? '</Definicion>' : isProp ? '</Propiedad>' : '</ErrorFrecuente>';

        const tituloMatch = line.match(/titulo="([^"]+)"/);
        const titulo = tituloMatch ? tituloMatch[1] : undefined;

        let content = '';
        i++;
        while (i < lines.length && !lines[i].includes(tagClose)) {
          content += lines[i] + '\n';
          i++;
        }
        i++; // salta tagClose

        if (isDef) {
          elements.push(
            <Definicion key={`box-${i}`} titulo={titulo}>
              <FormattedMathText text={content.trim()} />
            </Definicion>
          );
        } else if (isProp) {
          elements.push(
            <Propiedad key={`box-${i}`} titulo={titulo}>
              <FormattedMathText text={content.trim()} />
            </Propiedad>
          );
        } else {
          elements.push(
            <ErrorFrecuente key={`box-${i}`} titulo={titulo}>
              <FormattedMathText text={content.trim()} />
            </ErrorFrecuente>
          );
        }
        continue;
      }

      // 5. Encabezados Markdown
      if (line.startsWith('# ')) {
        elements.push(
          <h1 key={`h1-${i}`} className="text-4xl md:text-5xl font-bold tracking-tight text-white mb-3 mt-1">
            <FormattedMathText text={line.slice(2)} />
          </h1>
        );
        i++;
        continue;
      }

      if (line.startsWith('## ')) {
        elements.push(
          <h2 key={`h2-${i}`} className="text-2xl md:text-3xl font-semibold tracking-tight text-blue-300 mb-4 mt-2">
            <FormattedMathText text={line.slice(3)} />
          </h2>
        );
        i++;
        continue;
      }

      if (line.startsWith('### ')) {
        elements.push(
          <h3 key={`h3-${i}`} className="text-xl md:text-2xl font-medium text-slate-300 mb-3 mt-1">
            <FormattedMathText text={line.slice(4)} />
          </h3>
        );
        i++;
        continue;
      }

      // Separador horizontal
      if (line === '---') {
        elements.push(<hr key={`hr-${i}`} className="my-5 border-slate-800" />);
        i++;
        continue;
      }

      // Bloque de fórmula matemática aislada $$...$$
      if (line.startsWith('$$') && line.endsWith('$$') && line.length > 4) {
        const mathContent = line.slice(2, -2).trim();
        elements.push(
          <div key={`math-${i}`} className="my-4 py-2 bg-slate-900/60 rounded-xl border border-slate-800 shadow-inner">
            <MathFormula math={mathContent} block className="text-2xl text-blue-300 font-medium" />
          </div>
        );
        i++;
        continue;
      }

      // Lista de viñetas
      if (line.startsWith('- ')) {
        const listItems: string[] = [];
        while (i < lines.length && lines[i].trim().startsWith('- ')) {
          listItems.push(lines[i].trim().slice(2));
          i++;
        }
        elements.push(
          <ul key={`ul-${i}`} className="my-4 space-y-2.5 text-left list-none pl-1">
            {listItems.map((item, idx) => (
              <li key={idx} className="flex items-start gap-3 text-lg text-slate-200 leading-relaxed">
                <span className="w-2 h-2 rounded-full bg-blue-500 mt-2.5 shrink-0" />
                <div>
                  <FormattedMathText text={item} />
                </div>
              </li>
            ))}
          </ul>
        );
        continue;
      }

      // Párrafo estándar
      elements.push(
        <p key={`p-${i}`} className="text-lg md:text-xl text-slate-300 leading-relaxed my-3 text-left">
          <FormattedMathText text={line} />
        </p>
      );
      i++;
    }

    return elements;
  };

  return <div className="w-full flex flex-col justify-start">{renderContent()}</div>;
};
