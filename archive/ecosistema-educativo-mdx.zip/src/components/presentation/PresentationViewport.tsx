import React, { useRef, useState, useEffect } from 'react';

interface PresentationViewportProps {
  children: React.ReactNode;
  aspectRatio?: number; // 16 / 9 por defecto
}

export const PresentationViewport: React.FC<PresentationViewportProps> = ({
  children,
  aspectRatio = 16 / 9,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);

  // Dimensiones base del lienzo virtual (1920 x 1080 Full HD nativo)
  const baseWidth = 1920;
  const baseHeight = 1080;

  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current) return;
      const { clientWidth, clientHeight } = containerRef.current;

      // Dejamos un margen de seguridad de 24px para barra y bordes
      const availableWidth = clientWidth - 16;
      const availableHeight = clientHeight - 80; // reserva para la barra inferior táctil

      const scaleX = availableWidth / baseWidth;
      const scaleY = availableHeight / baseHeight;
      const currentScale = Math.min(scaleX, scaleY);

      setScale(Math.max(0.2, currentScale));
    };

    handleResize();

    const observer = new ResizeObserver(() => {
      handleResize();
    });

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    window.addEventListener('resize', handleResize);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
    };
  }, [baseWidth, baseHeight]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen flex flex-col items-center justify-center overflow-hidden bg-slate-950 select-none touch-none"
    >
      {/* Contenedor con Escala Vectorial 16:9 */}
      <div
        style={{
          width: `${baseWidth}px`,
          height: `${baseHeight}px`,
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
        }}
        className="shrink-0 rounded-2xl bg-gradient-to-b from-[#0f172a] to-[#0b0f19] border border-slate-800 shadow-2xl p-16 flex flex-col justify-between overflow-y-auto"
      >
        {children}
      </div>
    </div>
  );
};
