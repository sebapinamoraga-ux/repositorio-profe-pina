import React, { useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { MathFormula } from '../../lib/katex-renderer';

interface RectaNumericaProps {
  valorInicial?: number;
  operadorInicial?: '<' | '<=' | '>' | '>=';
}

export const RectaNumerica: React.FC<RectaNumericaProps> = ({
  valorInicial = 3,
  operadorInicial = '>=',
}) => {
  const [corte, setCorte] = useState<number>(valorInicial);
  const [operador, setOperador] = useState<'<' | '<=' | '>' | '>='>(operadorInicial);

  const ancho = 540;
  const alto = 140;
  const escala = 32;
  const centroX = ancho / 2;
  const posY = 75;

  const toSvgX = (val: number) => centroX + val * escala;

  const esEstricto = operador === '<' || operador === '>';
  const vaHaciaDerecha = operador === '>' || operador === '>=';

  const expresionLatex = React.useMemo(() => {
    const opLatex = operador === '<=' ? '\\le' : operador === '>=' ? '\\ge' : operador;
    const intervalo = vaHaciaDerecha
      ? esEstricto
        ? `]${corte}, +\\infty[`
        : `[${corte}, +\\infty[`
      : esEstricto
      ? `]-\\infty, ${corte}[`
      : `]-\\infty, ${corte}]`;

    return `x ${opLatex} ${corte} \\iff x \\in ${intervalo}`;
  }, [operador, corte, vaHaciaDerecha, esEstricto]);

  const xCorteSvg = toSvgX(corte);

  return (
    <div className="w-full my-4 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl text-left">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            Conjunto Solución en ℝ
          </span>
          <span className="text-xs text-slate-400 font-mono">
            {esEstricto ? 'Extremo abierto (no se incluye)' : 'Extremo cerrado (se incluye)'}
          </span>
        </div>

        <div className="bg-slate-950 px-4 py-1.5 rounded-xl border border-slate-700/80 shadow-inner">
          <MathFormula math={expresionLatex} className="text-lg text-emerald-400 font-bold" />
        </div>
      </div>

      {/* Gráfico SVG de la recta numérica */}
      <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 flex justify-center overflow-x-auto">
        <svg width={ancho} height={alto} viewBox={`0 0 ${ancho} ${alto}`} className="w-full max-w-[540px]">
          {/* Zona Rayada / Sombreada de la Solución */}
          {vaHaciaDerecha ? (
            <rect
              x={xCorteSvg}
              y={posY - 18}
              width={Math.max(0, ancho - xCorteSvg - 10)}
              height="36"
              fill="rgba(16, 185, 129, 0.2)"
              rx="4"
            />
          ) : (
            <rect
              x={10}
              y={posY - 18}
              width={Math.max(0, xCorteSvg - 10)}
              height="36"
              fill="rgba(16, 185, 129, 0.2)"
              rx="4"
            />
          )}

          {/* Flechas de la recta continua infinita */}
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748b" />
            </marker>
          </defs>

          {/* Eje principal */}
          <line
            x1={15}
            y1={posY}
            x2={ancho - 15}
            y2={posY}
            stroke="#64748b"
            strokeWidth="3"
            markerStart="url(#arrow)"
            markerEnd="url(#arrow)"
          />

          {/* Flecha gruesa de la solución */}
          {vaHaciaDerecha ? (
            <line
              x1={xCorteSvg}
              y1={posY}
              x2={ancho - 15}
              y2={posY}
              stroke="#10b981"
              strokeWidth="5"
              markerEnd="url(#arrow)"
            />
          ) : (
            <line
              x1={xCorteSvg}
              y1={posY}
              x2={15}
              y2={posY}
              stroke="#10b981"
              strokeWidth="5"
              markerEnd="url(#arrow)"
            />
          )}

          {/* Graduaciones de números enteros */}
          {[-6, -4, -2, 0, 2, 4, 6].map((num) => {
            const sx = toSvgX(num);
            return (
              <g key={num}>
                <line x1={sx} y1={posY - 7} x2={sx} y2={posY + 7} stroke="#475569" strokeWidth="2" />
                <text x={sx} y={posY + 26} fill="#94a3b8" fontSize="13" textAnchor="middle" fontFamily="monospace">
                  {num}
                </text>
              </g>
            );
          })}

          {/* Círculo del Punto Crítico (Abierto o Cerrado) */}
          <circle
            cx={xCorteSvg}
            cy={posY}
            r="8"
            fill={esEstricto ? '#090d16' : '#10b981'}
            stroke="#10b981"
            strokeWidth="3"
          />
          <text x={xCorteSvg} y={posY - 16} fill="#34d399" fontSize="13" fontWeight="bold" textAnchor="middle">
            {corte}
          </text>
        </svg>
      </div>

      {/* Controles para Tablet */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        {/* Selector de Operador de Inecuación */}
        <div className="flex gap-2">
          {(['<', '<=', '>', '>='] as const).map((op) => (
            <button
              key={op}
              type="button"
              onClick={() => setOperador(op)}
              className={`flex-1 py-3 px-2 rounded-xl font-bold font-mono text-base border transition ${
                operador === op
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {op === '<=' ? '≤' : op === '>=' ? '≥' : op}
            </button>
          ))}
        </div>

        {/* Ajuste del Valor Crítico con Botones Táctiles */}
        <div className="flex items-center gap-3 bg-slate-950 p-2 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setCorte((c) => Math.max(-6, c - 1))}
            className="w-11 h-11 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-lg active:scale-95 transition hover:bg-slate-700"
          >
            <Minus className="w-5 h-5" />
          </button>
          <div className="flex-1 text-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider block">Valor frontera</span>
            <span className="text-lg font-mono font-bold text-emerald-400">{corte}</span>
          </div>
          <button
            type="button"
            onClick={() => setCorte((c) => Math.min(6, c + 1))}
            className="w-11 h-11 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-lg active:scale-95 transition hover:bg-slate-700"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
