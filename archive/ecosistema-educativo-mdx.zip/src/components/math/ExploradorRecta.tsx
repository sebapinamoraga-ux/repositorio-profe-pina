import React, { useState } from 'react';
import { Minus, Plus, Compass } from 'lucide-react';
import { MathFormula } from '../../lib/katex-renderer';

interface ExploradorRectaProps {
  mInicial?: number;
  nInicial?: number;
}

export const ExploradorRecta: React.FC<ExploradorRectaProps> = ({
  mInicial = 2,
  nInicial = 1,
}) => {
  const [m, setM] = useState<number>(mInicial);
  const [n, setN] = useState<number>(nInicial);
  const [mostrarTriangulo, setMostrarTriangulo] = useState<boolean>(true);
  const [mostrarPuntosClave, setMostrarPuntosClave] = useState<boolean>(true);

  // Dimensiones del canvas SVG
  const width = 540;
  const height = 400;
  const escala = 30; // pixeles por unidad
  const centroX = width / 2;
  const centroY = height / 2;

  // Conversión de coordenadas matemáticas a píxeles
  const toSvgX = (x: number) => centroX + x * escala;
  const toSvgY = (y: number) => centroY - y * escala;

  // Puntos extremos para dibujar la recta
  const xMin = -8;
  const xMax = 8;
  const y1 = m * xMin + n;
  const y2 = m * xMax + n;

  // Puntos clave
  const corteY = { x: 0, y: n };
  const tieneCorteX = m !== 0;
  const corteX = tieneCorteX ? { x: -n / m, y: 0 } : null;

  // Triángulo de pendiente centrado en x=1
  const xTri = 1;
  const yTri1 = m * xTri + n;
  const dx = 1;
  const yTri2 = m * (xTri + dx) + n;

  // Formato LaTeX dinámico de la función
  const ecuacionLatex = React.useMemo(() => {
    if (m === 0 && n === 0) return 'f(x) = 0';
    let termM = '';
    if (m === 1) termM = 'x';
    else if (m === -1) termM = '-x';
    else if (m !== 0) termM = `${m}x`;

    let termN = '';
    if (n > 0) termN = m !== 0 ? `+ ${n}` : `${n}`;
    else if (n < 0) termN = m !== 0 ? `- ${Math.abs(n)}` : `-${Math.abs(n)}`;

    return `f(x) = ${termM} ${termN}`.trim();
  }, [m, n]);

  const esLineal = n === 0;

  return (
    <div className="w-full my-4 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl">
      {/* Barra de estado y ecuación */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className={`px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider ${
            esLineal ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
          }`}>
            {esLineal ? 'Función Lineal (Pasa por el Origen)' : 'Función Afín (Desplazada)'}
          </span>
          <span className="text-xs text-slate-400 font-mono">
            m = {m > 0 ? `+${m}` : m} {m > 0 ? '(Creciente)' : m < 0 ? '(Decreciente)' : '(Constante)'}
          </span>
        </div>

        <div className="bg-slate-950 px-4 py-1.5 rounded-xl border border-slate-700/80 shadow-inner">
          <MathFormula math={ecuacionLatex} className="text-xl text-blue-400 font-bold" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Gráfico Cartesiano SVG */}
        <div className="lg:col-span-7 flex justify-center bg-slate-950 rounded-xl p-2 border border-slate-800 relative overflow-hidden">
          <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="w-full h-auto max-w-[540px]">
            {/* Cuadrícula Cartesiana */}
            <defs>
              <pattern id="grid" width={escala} height={escala} patternUnits="userSpaceOnUse">
                <path d={`M ${escala} 0 L 0 0 0 ${escala}`} fill="none" stroke="#1e293b" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />

            {/* Eje X y Eje Y */}
            <line x1={0} y1={centroY} x2={width} y2={centroY} stroke="#475569" strokeWidth="1.5" />
            <line x1={centroX} y1={0} x2={centroX} y2={height} stroke="#475569" strokeWidth="1.5" />

            {/* Marcas de graduación */}
            {[-6, -4, -2, 2, 4, 6].map((val) => (
              <React.Fragment key={val}>
                <text x={toSvgX(val)} y={centroY + 16} fill="#64748b" fontSize="11" textAnchor="middle" fontFamily="monospace">
                  {val}
                </text>
                <text x={centroX - 10} y={toSvgY(val) + 4} fill="#64748b" fontSize="11" textAnchor="end" fontFamily="monospace">
                  {val}
                </text>
              </React.Fragment>
            ))}

            {/* Etiquetas de ejes */}
            <text x={width - 15} y={centroY - 8} fill="#94a3b8" fontSize="13" fontWeight="bold" fontFamily="monospace">
              X
            </text>
            <text x={centroX + 10} y={18} fill="#94a3b8" fontSize="13" fontWeight="bold" fontFamily="monospace">
              Y
            </text>

            {/* Triángulo de Pendiente Δy / Δx */}
            {mostrarTriangulo && m !== 0 && (
              <g className="transition-all duration-200">
                <line
                  x1={toSvgX(xTri)}
                  y1={toSvgY(yTri1)}
                  x2={toSvgX(xTri + dx)}
                  y2={toSvgY(yTri1)}
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeDasharray="4 3"
                />
                <line
                  x1={toSvgX(xTri + dx)}
                  y1={toSvgY(yTri1)}
                  x2={toSvgX(xTri + dx)}
                  y2={toSvgY(yTri2)}
                  stroke="#f43f5e"
                  strokeWidth="2"
                  strokeDasharray="4 3"
                />
                <text x={toSvgX(xTri + 0.5)} y={toSvgY(yTri1) + 14} fill="#38bdf8" fontSize="11" textAnchor="middle" fontWeight="bold">
                  Δx = 1
                </text>
                <text x={toSvgX(xTri + dx) + 8} y={toSvgY(yTri1 + m / 2)} fill="#f43f5e" fontSize="11" textAnchor="start" fontWeight="bold">
                  Δy = {m}
                </text>
              </g>
            )}

            {/* La Recta y = mx + n */}
            <line
              x1={toSvgX(xMin)}
              y1={toSvgY(y1)}
              x2={toSvgX(xMax)}
              y2={toSvgY(y2)}
              stroke="#3b82f6"
              strokeWidth="3.5"
              strokeLinecap="round"
            />

            {/* Puntos Clave */}
            {mostrarPuntosClave && (
              <>
                {/* Corte con el eje Y (0, n) */}
                <circle cx={toSvgX(0)} cy={toSvgY(n)} r="6" fill="#10b981" stroke="#047857" strokeWidth="2" />
                <text x={toSvgX(0) + 10} y={toSvgY(n) - 8} fill="#34d399" fontSize="12" fontWeight="bold">
                  (0, {n})
                </text>

                {/* Cero de la función (-n/m, 0) */}
                {corteX && (
                  <>
                    <circle cx={toSvgX(corteX.x)} cy={toSvgY(0)} r="6" fill="#f59e0b" stroke="#b45309" strokeWidth="2" />
                    <text x={toSvgX(corteX.x)} y={toSvgY(0) + 20} fill="#fbbf24" fontSize="12" fontWeight="bold" textAnchor="middle">
                      ({corteX.x.toFixed(1)}, 0)
                    </text>
                  </>
                )}
              </>
            )}
          </svg>
        </div>

        {/* Panel de Control Táctil (Optimizado para Tablet - Dedos) */}
        <div className="lg:col-span-5 flex flex-col gap-4 text-left">
          {/* Control Pendiente m */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-semibold text-slate-300">
                Pendiente <span className="text-blue-400 font-mono font-bold">(m)</span>
              </span>
              <span className="text-lg font-mono font-bold text-blue-400">{m}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setM((prev) => Math.max(-5, Math.round((prev - 0.5) * 10) / 10))}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold text-xl active:scale-95 transition"
                aria-label="Disminuir pendiente"
              >
                <Minus className="w-5 h-5" />
              </button>
              <input
                type="range"
                min="-5"
                max="5"
                step="0.5"
                value={m}
                onChange={(e) => setM(parseFloat(e.target.value))}
                className="flex-1 h-3 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <button
                type="button"
                onClick={() => setM((prev) => Math.min(5, Math.round((prev + 0.5) * 10) / 10))}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold text-xl active:scale-95 transition"
                aria-label="Aumentar pendiente"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Control Coeficiente n */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-semibold text-slate-300">
                Coeficiente de Posición <span className="text-emerald-400 font-mono font-bold">(n)</span>
              </span>
              <span className="text-lg font-mono font-bold text-emerald-400">{n}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setN((prev) => Math.max(-5, prev - 1))}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold text-xl active:scale-95 transition"
                aria-label="Disminuir coeficiente n"
              >
                <Minus className="w-5 h-5" />
              </button>
              <input
                type="range"
                min="-5"
                max="5"
                step="1"
                value={n}
                onChange={(e) => setN(parseInt(e.target.value, 10))}
                className="flex-1 h-3 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <button
                type="button"
                onClick={() => setN((prev) => Math.min(5, prev + 1))}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold text-xl active:scale-95 transition"
                aria-label="Aumentar coeficiente n"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Atajos Didácticos de 1 Toque */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => { setM(2); setN(0); }}
              className="py-2 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              Lineal (n = 0)
            </button>
            <button
              type="button"
              onClick={() => { setM(-1); setN(3); }}
              className="py-2 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              Decreciente (m &lt; 0)
            </button>
            <button
              type="button"
              onClick={() => { setM(0); setN(2); }}
              className="py-2 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              Constante (m = 0)
            </button>
            <button
              type="button"
              onClick={() => { setM(1); setN(1); }}
              className="py-2 px-3 rounded-lg text-xs font-semibold bg-blue-900/40 hover:bg-blue-900/60 text-blue-300 border border-blue-700/50 transition"
            >
              Restablecer (1, 1)
            </button>
          </div>

          {/* Toggles didácticos */}
          <div className="flex items-center justify-between pt-1 text-xs text-slate-400">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={mostrarTriangulo}
                onChange={(e) => setMostrarTriangulo(e.target.checked)}
                className="rounded border-slate-700 text-blue-600 focus:ring-0"
              />
              <span>Triángulo de Pendiente</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={mostrarPuntosClave}
                onChange={(e) => setMostrarPuntosClave(e.target.checked)}
                className="rounded border-slate-700 text-emerald-600 focus:ring-0"
              />
              <span>Puntos de Intersección</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
