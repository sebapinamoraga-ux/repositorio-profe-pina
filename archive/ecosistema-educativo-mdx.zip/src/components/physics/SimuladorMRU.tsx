import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, FastForward, Gauge } from 'lucide-react';
import { MathFormula } from '../../lib/katex-renderer';

interface SimuladorMRUProps {
  x0Inicial?: number;
  vInicial?: number;
}

export const SimuladorMRU: React.FC<SimuladorMRUProps> = ({
  x0Inicial = 0,
  vInicial = 3,
}) => {
  const [x0, setX0] = useState<number>(x0Inicial);
  const [v, setV] = useState<number>(vInicial);
  const [tiempo, setTiempo] = useState<number>(0);
  const [corriendo, setCorriendo] = useState<boolean>(false);

  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number | null>(null);

  // Posición calculada en tiempo real: x(t) = x0 + v * t
  const posicion = x0 + v * tiempo;

  // Parámetros de animación
  useEffect(() => {
    if (!corriendo) {
      lastTimeRef.current = null;
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      return;
    }

    const animate = (time: number) => {
      if (lastTimeRef.current !== null) {
        const deltaSeconds = (time - lastTimeRef.current) / 1000;
        setTiempo((tPrev) => {
          const nuevoT = tPrev + deltaSeconds;
          // Limitar a 10 segundos
          if (nuevoT >= 10) {
            setCorriendo(false);
            return 10;
          }
          return nuevoT;
        });
      }
      lastTimeRef.current = time;
      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [corriendo]);

  const handleReset = () => {
    setCorriendo(false);
    setTiempo(0);
  };

  const handlePaso = () => {
    setCorriendo(false);
    setTiempo((t) => Math.min(10, Math.round((t + 0.5) * 10) / 10));
  };

  // Dimensiones del escenario
  const ancho = 560;
  const altoPista = 120;
  const escalaX = 22; // px por metro
  const centroX = 140;

  const toSvgX = (xMetros: number) => centroX + xMetros * escalaX;
  const xCarroSvg = toSvgX(posicion);

  return (
    <div className="w-full my-4 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl text-left">
      {/* Header técnico con ecuación de itinerario */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
            Física: Mecánica (MRU)
          </span>
          <span className="text-xs text-slate-400 font-mono">
            Velocidad constante (aceleración nula)
          </span>
        </div>

        <div className="bg-slate-950 px-4 py-1.5 rounded-xl border border-slate-700/80 shadow-inner">
          <MathFormula
            math={`x(t) = ${x0} + (${v})\\cdot t = ${posicion.toFixed(1)}\\text{ m}`}
            className="text-lg text-amber-400 font-bold"
          />
        </div>
      </div>

      {/* Pista de simulación interactiva */}
      <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 overflow-hidden relative">
        <svg width={ancho} height={altoPista} viewBox={`0 0 ${ancho} ${altoPista}`} className="w-full max-w-[560px]">
          {/* Eje de referencia de posición */}
          <line x1={20} y1={80} x2={ancho - 20} y2={80} stroke="#475569" strokeWidth="2.5" />

          {/* Marcas de distancia (metros) */}
          {[-4, -2, 0, 2, 4, 6, 8, 10, 12, 14, 16].map((m) => {
            const sx = toSvgX(m);
            if (sx < 20 || sx > ancho - 20) return null;
            return (
              <g key={m}>
                <line x1={sx} y1={72} x2={sx} y2={88} stroke="#64748b" strokeWidth="1.5" />
                <text x={sx} y={105} fill="#94a3b8" fontSize="11" textAnchor="middle" fontFamily="monospace">
                  {m}m
                </text>
              </g>
            );
          })}

          {/* Origen (0 metros) */}
          <line x1={toSvgX(0)} y1={65} x2={toSvgX(0)} y2={95} stroke="#38bdf8" strokeWidth="2.5" />
          <text x={toSvgX(0)} y={58} fill="#38bdf8" fontSize="11" textAnchor="middle" fontWeight="bold">
            x = 0
          </text>

          {/* Móvil / Vehículo */}
          <g transform={`translate(${xCarroSvg}, 60)`} className="transition-transform duration-75">
            {/* Cuerpo del carro */}
            <rect x="-24" y="-18" width="48" height="22" rx="5" fill="#f59e0b" stroke="#d97706" strokeWidth="2" />
            {/* Ventanas */}
            <rect x="-14" y="-14" width="12" height="9" rx="2" fill="#1e293b" />
            <rect x="2" y="-14" width="12" height="9" rx="2" fill="#1e293b" />
            {/* Ruedas */}
            <circle cx="-14" cy="6" r="6" fill="#0f172a" stroke="#64748b" strokeWidth="2" />
            <circle cx="14" cy="6" r="6" fill="#0f172a" stroke="#64748b" strokeWidth="2" />

            {/* Vector Velocidad v (Flecha Roja) */}
            {v !== 0 && (
              <g>
                <defs>
                  <marker id="vArrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#ef4444" />
                  </marker>
                </defs>
                <line
                  x1={0}
                  y1={-26}
                  x2={v * 8}
                  y2={-26}
                  stroke="#ef4444"
                  strokeWidth="3.5"
                  markerEnd="url(#vArrow)"
                />
                <text x={v * 4} y={-32} fill="#ef4444" fontSize="12" fontWeight="bold" textAnchor="middle">
                  v = {v} m/s
                </text>
              </g>
            )}
          </g>
        </svg>

        {/* Marcador digital de telemetría */}
        <div className="flex justify-between items-center px-2 pt-2 text-xs font-mono text-slate-400">
          <div>
            Cronómetro: <span className="text-white font-bold text-sm">{tiempo.toFixed(2)} s</span>
          </div>
          <div>
            Posición: <span className="text-amber-400 font-bold text-sm">{posicion.toFixed(2)} m</span>
          </div>
          <div>
            Desplazamiento Δx: <span className="text-emerald-400 font-bold text-sm">{(posicion - x0).toFixed(2)} m</span>
          </div>
        </div>
      </div>

      {/* Controles Ergonómicos para Tablet */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-4 items-center">
        {/* Botones de Reproducción */}
        <div className="md:col-span-5 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCorriendo(!corriendo)}
            className={`flex-1 py-3 px-4 rounded-xl font-bold flex items-center justify-center gap-2 transition shadow-md active:scale-95 ${
              corriendo ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {corriendo ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            <span>{corriendo ? 'Pausar' : 'Iniciar'}</span>
          </button>
          <button
            type="button"
            onClick={handlePaso}
            className="py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center transition"
            title="Paso a paso (+0.5 s)"
          >
            <FastForward className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition"
            title="Reiniciar a t=0"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Ajuste de Posición Inicial x0 y Velocidad v */}
        <div className="md:col-span-7 flex gap-3">
          {/* x0 */}
          <div className="flex-1 bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">x₀:</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => { setX0((x) => Math.max(-4, x - 1)); setTiempo(0); }}
                className="w-8 h-8 rounded-lg bg-slate-800 text-white font-bold text-sm hover:bg-slate-700"
              >
                -
              </button>
              <span className="font-mono font-bold text-sm text-slate-200 w-8 text-center">{x0}m</span>
              <button
                type="button"
                onClick={() => { setX0((x) => Math.min(6, x + 1)); setTiempo(0); }}
                className="w-8 h-8 rounded-lg bg-slate-800 text-white font-bold text-sm hover:bg-slate-700"
              >
                +
              </button>
            </div>
          </div>

          {/* v */}
          <div className="flex-1 bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">v:</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => { setV((vel) => Math.max(-5, vel - 1)); setTiempo(0); }}
                className="w-8 h-8 rounded-lg bg-slate-800 text-white font-bold text-sm hover:bg-slate-700"
              >
                -
              </button>
              <span className="font-mono font-bold text-sm text-red-400 w-10 text-center">{v}m/s</span>
              <button
                type="button"
                onClick={() => { setV((vel) => Math.min(6, vel + 1)); setTiempo(0); }}
                className="w-8 h-8 rounded-lg bg-slate-800 text-white font-bold text-sm hover:bg-slate-700"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
