import React from 'react';
import katex from 'katex';

interface MathFormulaProps {
  math: string;
  block?: boolean;
  className?: string;
}

export const MathFormula: React.FC<MathFormulaProps> = ({ math, block = false, className = '' }) => {
  const html = React.useMemo(() => {
    try {
      return katex.renderToString(math.trim(), {
        displayMode: block,
        throwOnError: false,
        strict: false,
      });
    } catch (error) {
      console.error('Error rendering KaTeX:', error);
      return `<span class="text-red-500 font-mono text-sm">[Error LaTeX: ${math}]</span>`;
    }
  }, [math, block]);

  return (
    <span
      className={`${block ? 'block my-3 text-center overflow-x-auto py-1' : 'inline-block px-1 align-baseline'} ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

/**
 * Parser de texto que detecta fórmulas LaTeX delimitadas por $$ o $
 */
export const FormattedMathText: React.FC<{ text: string; className?: string }> = ({ text, className = '' }) => {
  const parts = React.useMemo(() => {
    // Busca bloques $$...$$ y en línea $...$
    const tokens: Array<{ type: 'text' | 'inline-math' | 'block-math'; content: string }> = [];
    const regex = /(\$\$[\s\S]*?\$\$|\$[^\$\n]+?\$)/g;
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        tokens.push({
          type: 'text',
          content: text.substring(lastIndex, match.index),
        });
      }

      const raw = match[0];
      if (raw.startsWith('$$') && raw.endsWith('$$')) {
        tokens.push({
          type: 'block-math',
          content: raw.slice(2, -2),
        });
      } else if (raw.startsWith('$') && raw.endsWith('$')) {
        tokens.push({
          type: 'inline-math',
          content: raw.slice(1, -1),
        });
      }
      lastIndex = regex.lastIndex;
    }

    if (lastIndex < text.length) {
      tokens.push({
        type: 'text',
        content: text.substring(lastIndex),
      });
    }

    return tokens;
  }, [text]);

  return (
    <span className={className}>
      {parts.map((token, index) => {
        if (token.type === 'block-math') {
          return <MathFormula key={index} math={token.content} block />;
        }
        if (token.type === 'inline-math') {
          return <MathFormula key={index} math={token.content} block={false} />;
        }
        return <span key={index}>{token.content}</span>;
      })}
    </span>
  );
};
