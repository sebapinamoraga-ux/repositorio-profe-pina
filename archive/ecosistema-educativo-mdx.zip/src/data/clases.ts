import { ClaseCompleta } from '../types';

export const CLASES_DATA: ClaseCompleta[] = [
  {
    id: 'm1-algebra-01',
    titulo: 'Ecuaciones e Inecuaciones de Primer Grado',
    subtitulo: 'Resolución analítica, propiedades de desigualdad y modelamiento formal',
    disciplina: 'matematica',
    ejeTematico: 'Álgebra y Funciones',
    codigoPAES: 'PAES M1 - DEMRE',
    duracionMinutos: 90,
    autor: 'Docencia PAES',
    rawMDX: '',
    slides: [
      {
        id: 's1-1',
        titulo: 'Ecuaciones e Inecuaciones Lineales',
        categoria: 'Portada & Objetivos',
        rawContent: `
# Ecuaciones e Inecuaciones de Primer Grado
### Eje Álgebra y Funciones — Preparación PAES Regular M1

---

### Habilidades DEMRE a desarrollar en esta clase:
- **Resolver problemas:** Aplicar operatoria y algoritmos de despeje respetando las propiedades algebraicas en $\\mathbb{R}$.
- **Modelar:** Traducir situaciones del lenguaje natural a igualdades o desigualdades formales.
- **Representar:** Expresar el conjunto solución algebraicamente, por comprensión y geométricamente en la recta real.
        `,
      },
      {
        id: 's1-2',
        titulo: 'La Ecuación Lineal y el Principio de Balanza',
        categoria: 'Fundamentos',
        rawContent: `
## ¿Qué es una Ecuación de Primer Grado?

Una ecuación lineal en una variable es una igualdad algebraica reducible a la forma canónica:

$$ax + b = 0 \\quad (\\text{con } a, b \\in \\mathbb{R}, \\; a \\neq 0)$$

<Definicion titulo="Solución Única">
El valor que satisface la igualdad se obtiene aplicando la propiedad del inverso aditivo y multiplicativo:
$$x = -\\frac{b}{a}$$
</Definicion>

<Propiedad titulo="Propiedad Uniforme de la Igualdad">
Si sumamos, restamos, multiplicamos o dividimos (por un número distinto de cero) la misma cantidad en ambos miembros, **la igualdad se mantiene inalterada**.
</Propiedad>
        `,
      },
      {
        id: 's1-3',
        titulo: 'Deducción Paso a Paso: Ecuación con Fracciones',
        categoria: 'Deducción',
        rawContent: `
## Procedimiento de Resolución Formal

Resolvamos la ecuación: $\\frac{2x - 1}{3} - \\frac{x + 2}{4} = 1$

<PasoRevelado pasos={[
  {
    titulo: "1. Encontrar el Mínimo Común Múltiplo",
    detalle: "El $\\text{m.c.m.}(3, 4) = 12$. Multiplicamos toda la ecuación por $12$ para eliminar los denominadores."
  },
  {
    titulo: "2. Distribuir el factor en cada término",
    detalle: "$12 \\cdot \\left(\\frac{2x - 1}{3}\\right) - 12 \\cdot \\left(\\frac{x + 2}{4}\\right) = 12 \\cdot 1 \\implies 4(2x - 1) - 3(x + 2) = 12$"
  },
  {
    titulo: "3. Expandir paréntesis (¡Cuidado con el signo negativo!)",
    detalle: "$8x - 4 - 3x - 6 = 12 \\implies 5x - 10 = 12$"
  },
  {
    titulo: "4. Despejar la incógnita x",
    detalle: "$5x = 12 + 10 \\implies 5x = 22 \\implies x = \\frac{22}{5}$"
  }
]} />
        `,
      },
      {
        id: 's1-4',
        titulo: 'Inecuaciones Lineales y la Regla del Signo',
        categoria: 'Desigualdades',
        rawContent: `
## Inecuaciones de Primer Grado

Una inecuación es una desigualdad entre expresiones algebraicas donde la solución suele ser un **conjunto infinito de números** (un intervalo en $\\mathbb{R}$).

<ErrorFrecuente titulo="¡El Error más penalizado en la PAES!">
Al multiplicar o dividir ambos lados de una desigualdad por un **número negativo**, el sentido de la desigualdad **se invierte obligatoriamente**:
$$-\\frac{1}{2}x < 4 \\quad \\xrightarrow{\\text{multiplicar por } (-2)} \\quad x > -8$$
*(Si no inviertes el signo, todo el conjunto solución queda erróneo).*
</ErrorFrecuente>
        `,
      },
      {
        id: 's1-5',
        titulo: 'Visualizador de Conjuntos Solución en la Recta',
        categoria: 'Herramienta Interactiva',
        rawContent: `
## Representación Geométrica del Intervalo

Explora cómo varía el conjunto solución al modificar el operador $(\\le, \\ge, <, >)$ y el valor frontera:

<RectaNumerica valorInicial={2} operadorInicial=">=" />
        `,
      },
      {
        id: 's1-6',
        titulo: 'Pregunta Oficial Tipo PAES M1',
        categoria: 'Evaluación Formativa',
        rawContent: `
## Desafío en Aula: Inecuaciones Lineales

<PreguntaPAES
  habilidad="Resolver Problemas"
  eje="Álgebra y Funciones"
  enunciado="Si $3(x - 2) \\le 5x + 4$, ¿cuál es el conjunto de todos los números reales $x$ que satisfacen la inecuación?"
  opciones={[
    {
      id: "A",
      texto: "$x \\le -5$",
      esCorrecta: false,
      distractorExplicacion: "Ocurre si se olvida invertir el sentido de la desigualdad al dividir por $-2$."
    },
    {
      id: "B",
      texto: "$x \\ge -5$",
      esCorrecta: true,
      justificacion: "Desarrollando: $3x - 6 \\le 5x + 4 \\implies 3x - 5x \\le 4 + 6 \\implies -2x \\le 10$. Al dividir por $-2$, se invierte el sentido: $x \\ge \\frac{10}{-2} \\implies x \\ge -5$."
    },
    {
      id: "C",
      texto: "$x \\ge 5$",
      esCorrecta: false,
      distractorExplicacion: "Error de signos al pasar los términos numéricos al miembro derecho."
    },
    {
      id: "D",
      texto: "$x \\le 5$",
      esCorrecta: false,
      distractorExplicacion: "Doble error de signo y no inversión del sentido de la inecuación."
    }
  ]}
/>
        `,
      },
    ],
  },
  {
    id: 'm1-algebra-02',
    titulo: 'Función Lineal y Función Afín',
    subtitulo: 'Pendiente, coeficiente de posición, gráficos cartesianos y modelamiento',
    disciplina: 'matematica',
    ejeTematico: 'Álgebra y Funciones',
    codigoPAES: 'PAES M1 - DEMRE',
    duracionMinutos: 90,
    autor: 'Docencia PAES',
    rawMDX: '',
    slides: [
      {
        id: 's2-1',
        titulo: 'Función Lineal y Afín',
        categoria: 'Portada & Objetivos',
        rawContent: `
# Función Lineal y Función Afín
### Modelamiento gráfico y algebraico de relaciones constantes — PAES M1

---

### Lo que exige el temario DEMRE:
- Distinguir rigurosamente entre **función lineal** y **función afín**.
- Interpretar el significado físico y geométrico de la **pendiente** ($m$) y el **coeficiente de posición** ($n$).
- Determinar la ecuación de la recta dados dos puntos o un punto y la pendiente.
- Modelar situaciones cotidianas (tarifas con costo fijo + variable).
        `,
      },
      {
        id: 's2-2',
        titulo: 'Diferencia Esencial: Lineal vs Afín',
        categoria: 'Definiciones Clave',
        rawContent: `
## Dos Modelos de Variación Proporcional

<div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2">
  <Definicion titulo="Función Lineal">
    Tiene la forma:
    $$f(x) = m \\cdot x$$
    - Pasa siempre por el **origen de coordenadas** $(0,0)$.
    - Modela situaciones de **proporcionalidad directa estricta** (si $x=0$, $y=0$).
  </Definicion>

  <Definicion titulo="Función Afín">
    Tiene la forma:
    $$f(x) = m \\cdot x + n \\quad (n \\neq 0)$$
    - Corta al eje $Y$ en el punto $(0, n)$.
    - $n$ representa el **valor inicial** o **cargo fijo**.
  </Definicion>
</div>
        `,
      },
      {
        id: 's2-3',
        titulo: 'Simulador en Vivo: Explorador de la Recta',
        categoria: 'Herramienta Interactiva',
        rawContent: `
## Exploración Interactiva en Tiempo Real

Modifica la pendiente $m$ y el corte $n$ para observar cómo cambia la recta, su crecimiento y sus intersecciones:

<ExploradorRecta mInicial={1.5} nInicial={2} />
        `,
      },
      {
        id: 's2-4',
        titulo: 'Cálculo de la Pendiente: Tasa de Cambio',
        categoria: 'Concepto Central',
        rawContent: `
## La Pendiente como Razón de Cambio

Dados dos puntos distintos $P_1(x_1, y_1)$ y $P_2(x_2, y_2)$ sobre la recta:

$$m = \\frac{\\Delta y}{\\Delta x} = \\frac{y_2 - y_1}{x_2 - x_1}$$

<Propiedad titulo="Criterio de Crecimiento por el Signo de m">
- **$m > 0$:** La función es **estrictamente creciente** (sube de izquierda a derecha).
- **$m < 0$:** La función es **estrictamente decreciente** (baja de izquierda a derecha).
- **$m = 0$:** La función es **constante** ($f(x) = n$, recta horizontal).
</Propiedad>
        `,
      },
      {
        id: 's2-5',
        titulo: 'Pregunta Oficial Tipo PAES M1',
        categoria: 'Evaluación Formativa',
        rawContent: `
## Pregunta de Modelamiento en Contexto Real

<PreguntaPAES
  habilidad="Modelar"
  eje="Álgebra y Funciones"
  enunciado="Una empresa de transporte cobra una tarifa base de $\\$1.200$ más $\\$450$ por cada kilómetro recorrido. Si $x$ representa los kilómetros recorridos y $C(x)$ el costo total en pesos, ¿cuál de las siguientes funciones modela correctamente el cobro?"
  opciones={[
    {
      id: "A",
      texto: "$C(x) = 1.200x + 450$",
      esCorrecta: false,
      distractorExplicacion: "Invierte el cargo fijo con el cobro variable por kilómetro."
    },
    {
      id: "B",
      texto: "$C(x) = 450x + 1.200$",
      esCorrecta: true,
      justificacion: "El cobro variable depende de los kilómetros: $450 \\cdot x$, y se le añade el cargo fijo inicial de $\\$1.200$. Corresponde a una función afín con $m=450$ y $n=1200$."
    },
    {
      id: "C",
      texto: "$C(x) = (1.200 + 450)x$",
      esCorrecta: false,
      distractorExplicacion: "Aplica erróneamente la tarifa base a cada kilómetro recorrido."
    },
    {
      id: "D",
      texto: "$C(x) = 1.200x - 450$",
      esCorrecta: false,
      distractorExplicacion: "Aplica una resta sin justificación en el modelo de cobro."
    }
  ]}
/>
        `,
      },
    ],
  },
  {
    id: 'fisica-mecanica-01',
    titulo: 'Cinemática: Movimiento Rectilíneo Uniforme (MRU)',
    subtitulo: 'Sistemas de referencia, posición, velocidad constante y ecuación de itinerario',
    disciplina: 'fisica',
    ejeTematico: 'Mecánica',
    codigoPAES: 'PAES Ciencias - DEMRE',
    duracionMinutos: 90,
    autor: 'Docencia PAES',
    rawMDX: '',
    slides: [
      {
        id: 's3-1',
        titulo: 'Movimiento Rectilíneo Uniforme (MRU)',
        categoria: 'Portada & Objetivos',
        rawContent: `
# Cinemática: Movimiento Rectilíneo Uniforme
### Eje Mecánica — Prueba Electiva de Ciencias (Física)

---

### Habilidades Científicas DEMRE:
- **Procesar y analizar la evidencia:** Interpretar gráficos posición vs tiempo y velocidad vs tiempo.
- **Modelar:** Describir el itinerario de un cuerpo mediante la ecuación de movimiento con velocidad vectorial constante.
- **Relatividad de Galileo:** Comprender que el estado de movimiento depende críticamente del sistema de referencia elegido.
        `,
      },
      {
        id: 's3-2',
        titulo: 'Diferencia Vectorial: Desplazamiento vs Distancia',
        categoria: 'Conceptos Físicos',
        rawContent: `
## Las Magnitudes Fundamentales del Movimiento

<div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2">
  <Definicion titulo="Posición y Desplazamiento (Vectoriales)">
    - **Posición $\\vec{x}(t)$:** Ubicación respecto a un origen coordenado.
    - **Desplazamiento $\\Delta\\vec{x}$:** Vector que une la posición inicial con la final:
    $$\\Delta\\vec{x} = \\vec{x}_f - \\vec{x}_i$$
  </Definicion>

  <Definicion titulo="Distancia Recorrida (Escalar)">
    - Longitud real de la trayectoria seguida por el móvil ($d$).
    - Siempre es un valor real **positivo o cero** ($d \\ge 0$).
    - Sólo coincide con $|\\Delta\\vec{x}|$ si el movimiento es rectilíneo y sin cambios de sentido.
  </Definicion>
</div>
        `,
      },
      {
        id: 's3-3',
        titulo: 'Ecuación de Itinerario del MRU',
        categoria: 'Leyes del Movimiento',
        rawContent: `
## Ecuación de Itinerario con Velocidad Constante

Cuando un móvil se desplaza en línea recta sin acelerar (aceleración $\\vec{a} = 0$), su velocidad instantánea coincide con su velocidad media en todo intervalo:

$$v = \\frac{\\Delta x}{\\Delta t} = \\frac{x(t) - x_0}{t - 0}$$

Despejando la posición en función del tiempo:

$$x(t) = x_0 + v \\cdot t$$

<Propiedad titulo="Pendiente en el Gráfico Posición vs Tiempo">
En un gráfico de **Posición vs Tiempo ($x-t$)**, la trayectoria es una recta cuya **pendiente** representa exactamente la **velocidad ($v$)** del móvil.
</Propiedad>
        `,
      },
      {
        id: 's3-4',
        titulo: 'Simulador en Vivo: Móvil y Vector Velocidad',
        categoria: 'Simulación Interactiva',
        rawContent: `
## Laboratorio Virtual de Cinemática

Observa el desplazamiento del móvil, el vector de velocidad $\\vec{v}$ (flecha roja) y la evolución temporal del itinerario:

<SimuladorMRU x0Inicial={0} vInicial={3} />
        `,
      },
      {
        id: 's3-5',
        titulo: 'Pregunta Oficial Tipo PAES Física',
        categoria: 'Evaluación Científica',
        rawContent: `
## Análisis de Evidencia: Gráficos de Cinemática

<PreguntaPAES
  habilidad="Procesar y analizar la evidencia"
  eje="Mecánica (MRU)"
  enunciado="Un móvil se desplaza en línea recta a lo largo del eje X. Si su posición está descrita por la ecuación $x(t) = -6 + 2t$ (con $x$ en metros y $t$ en segundos), ¿cuál de las siguientes afirmaciones es correcta?"
  opciones={[
    {
      id: "A",
      texto: "El móvil parte desde el origen y se mueve a $2\\text{ m/s}$.",
      esCorrecta: false,
      distractorExplicacion: "Confunde la posición inicial $x_0 = -6\\text{ m}$ con el origen de coordenadas $x = 0$."
    },
    {
      id: "B",
      texto: "Al cabo de $3\\text{ segundos}$, el móvil se encuentra en el origen $x = 0$.",
      esCorrecta: true,
      justificacion: "Evaluando en $t = 3$: $x(3) = -6 + 2(3) = -6 + 6 = 0\\text{ m}$. Por lo tanto, el móvil cruza exactamente el origen a los 3 segundos."
    },
    {
      id: "C",
      texto: "La aceleración del móvil es de $2\\text{ m/s}^2$.",
      esCorrecta: false,
      distractorExplicacion: "Confunde la velocidad constante ($2\\text{ m/s}$) con la aceleración (que es cero en el MRU)."
    },
    {
      id: "D",
      texto: "La rapidez del móvil va disminuyendo a medida que transcurre el tiempo.",
      esCorrecta: false,
      distractorExplicacion: "El movimiento es uniforme, por lo que la rapidez permanece estrictamente constante en $2\\text{ m/s}$."
    }
  ]}
/>
        `,
      },
    ],
  },
];
