/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { PresentationViewport } from './components/presentation/PresentationViewport';
import { MarkdownSlideRenderer } from './components/presentation/MarkdownSlideRenderer';
import { TouchControls } from './components/presentation/TouchControls';
import { SlideDrawer } from './components/presentation/SlideDrawer';
import { CLASES_DATA } from './data/clases';
import { BookOpen, Atom, HelpCircle, Layers } from 'lucide-react';

export default function App() {
  const [claseId, setClaseId] = useState<string>('m1-algebra-02'); // Inicia por defecto con Función Lineal y Afín
  const [slideIndex, setSlideIndex] = useState<number>(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [mostrarGuiaTeclas, setMostrarGuiaTeclas] = useState<boolean>(false);

  // Clase actual y Diapositiva actual
  const claseActiva = CLASES_DATA.find((c) => c.id === claseId) || CLASES_DATA[0];
  const slideActual = claseActiva.slides[slideIndex] || claseActiva.slides[0];
  const totalSlides = claseActiva.slides.length;

  // Navegación
  const siguienteSlide = useCallback(() => {
    setSlideIndex((prev) => Math.min(totalSlides - 1, prev + 1));
  }, [totalSlides]);

  const anteriorSlide = useCallback(() => {
    setSlideIndex((prev) => Math.max(0, prev - 1));
  }, []);

  const irASlide = (index: number) => {
    if (index >= 0 && index < totalSlides) {
      setSlideIndex(index);
    }
  };

  const cambiarClase = (nuevaClaseId: string) => {
    setClaseId(nuevaClaseId);
    setSlideIndex(0);
    setIsDrawerOpen(false);
  };

  // Atajos de teclado (Clicker USB / Teclado)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignorar si se está escribiendo en algún input o textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
        e.preventDefault();
        siguienteSlide();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        anteriorSlide();
      } else if (e.key === 'm' || e.key === 'M') {
        setIsDrawerOpen((prev) => !prev);
      } else if (e.key === 'h' || e.key === 'H' || e.key === '?') {
        setMostrarGuiaTeclas((prev) => !prev);
      } else if (e.key === 'Home') {
        setSlideIndex(0);
      } else if (e.key === 'End') {
        setSlideIndex(totalSlides - 1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [siguienteSlide, anteriorSlide, totalSlides]);

  const esMatematica = claseActiva.disciplina === 'matematica';

  return (
    <main className="w-full h-screen bg-[#070a12] text-slate-100 overflow-hidden relative font-sans">
      {/* Viewport 16:9 con auto-escalado para proyector o tablet */}
      <PresentationViewport>
        {/* Encabezado de la diapositiva */}
        <header className="flex items-center justify-between pb-6 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-4">
            <div
              className={`px-3.5 py-1.5 rounded-xl font-mono text-sm font-bold flex items-center gap-2 tracking-wide uppercase ${
                esMatematica
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}
            >
              {esMatematica ? <BookOpen className="w-4 h-4" /> : <Atom className="w-4 h-4" />}
              <span>{claseActiva.codigoPAES}</span>
            </div>

            <div className="text-left">
              <span className="text-xs font-mono uppercase tracking-widest text-slate-400 block">
                {claseActiva.ejeTematico}
              </span>
              <span className="text-base font-semibold text-slate-200 block truncate max-w-xl">
                {claseActiva.titulo}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {slideActual.categoria && (
              <span className="px-3 py-1 rounded-lg text-xs font-semibold uppercase tracking-wider bg-slate-800 text-slate-400 border border-slate-700/60">
                {slideActual.categoria}
              </span>
            )}

            <span className="font-mono text-sm font-bold px-3 py-1 rounded-lg bg-slate-900 border border-slate-700/80 text-blue-400">
              {slideIndex + 1} / {totalSlides}
            </span>
          </div>
        </header>

        {/* Contenido Principal de la Diapositiva */}
        <div className="flex-1 my-6 overflow-y-auto pr-2">
          <MarkdownSlideRenderer rawContent={slideActual.rawContent} />
        </div>

        {/* Pie de diapositiva discreto */}
        <footer className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Fuente Única: MDX + KaTeX + Interactivos</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setMostrarGuiaTeclas(!mostrarGuiaTeclas)}
              className="text-slate-400 hover:text-slate-200 flex items-center gap-1 transition"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Atajos de Aula</span>
            </button>
            <span>{claseActiva.autor}</span>
          </div>
        </footer>
      </PresentationViewport>

      {/* Dock Táctil Flotante para Tablet */}
      <TouchControls
        slideActual={slideIndex}
        totalSlides={totalSlides}
        tituloClase={claseActiva.titulo}
        codigoPAES={claseActiva.codigoPAES}
        onAnterior={anteriorSlide}
        onSiguiente={siguienteSlide}
        onIrASlide={irASlide}
        onAbrirMenu={() => setIsDrawerOpen(true)}
      />

      {/* Menú Lateral de Selección de Clases y Diapositivas */}
      <SlideDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        clases={CLASES_DATA}
        claseActualId={claseId}
        slideActualIndex={slideIndex}
        onSeleccionarClase={cambiarClase}
        onSeleccionarSlide={irASlide}
      />

      {/* Modal de Ayuda / Atajos para Docencia */}
      {mostrarGuiaTeclas && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 p-6 rounded-2xl shadow-2xl text-left">
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-800">
              <h3 className="font-bold text-lg text-white">Controles de Presentación en Aula</h3>
              <button
                type="button"
                onClick={() => setMostrarGuiaTeclas(false)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1 bg-slate-800 rounded-lg"
              >
                Cerrar
              </button>
            </div>

            <div className="space-y-3 text-sm text-slate-300">
              <div className="flex justify-between">
                <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-xs text-blue-300">→ / Espacio / Clicker</span>
                <span>Avanzar diapositiva</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-xs text-blue-300">← / Clicker Atrás</span>
                <span>Retroceder diapositiva</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-xs text-blue-300">M</span>
                <span>Abrir menú de clases</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-xs text-blue-300">F</span>
                <span>Modo Pantalla Completa</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-xs text-blue-300">Tablet (Dedos)</span>
                <span>Dock flotante con botones táctiles de 50px</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
